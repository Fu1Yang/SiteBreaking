<footer>
    <h2>© 2024 Breaking Journey. Tous droits réservés.</h2>
    <div class="politique">
    <a href="privacy-policy.html" style="color: #00f;">Politique de confidentialité</a>
    <a href="cookie-policy.html" style="color: #00f;">Politique de cookies</a>
    </div>

  </footer>
</body>

</html>