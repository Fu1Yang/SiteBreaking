<nav>
    <div class="logo">
      <img class="fb1" src="./assets/logo/logo.png" alt="">
      <a href="https://www.facebook.com/bboybgirljourney/"><img src="./assets/logo/logo_fb.png" alt=""></a>
    </div>
    <div class="menu">
      <a href="../evenement">Evenement</a>
      <a href="../">Accueil</a>
      <a href="../contact">Contact</a>
    </div>
    <button class="rentrerCompte"><a href="../connexion">Administrateur</a></button>
  </nav>