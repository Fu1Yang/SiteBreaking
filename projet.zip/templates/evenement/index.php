<?php require_once(__DIR__ . '/../includes/headerEvenement.php'); ?>
<?php require_once(__DIR__ . '/../includes/navEvenement.php'); ?>


<h1>Les Evenements </h1>


    <?php require_once(__DIR__ . '/../compteAdmin/liste/listeEvenement.php');?>










<?php require_once(__DIR__ . '/../includes/footer.php') ?>