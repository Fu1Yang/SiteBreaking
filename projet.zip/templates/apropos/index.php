<?php require_once(__DIR__ . '/../includes/headerApropos.php'); ?>
<?php require_once(__DIR__ . '/../includes/navApropos.php'); ?>



<?php require_once(__DIR__ . '/../compteAdmin/liste/listeApropos.php');?>



<div class="associative">
    <div id="h1"><h1>Nos partenaires</h1></div>
    <div id="nosPartenaires" class="flex-container">
        <?php require_once(__DIR__ . '/../compteAdmin/liste/listePartenaire.php');?>
    </div>
</div>


<?php require_once(__DIR__ . '/../includes/footer.php'); ?>















