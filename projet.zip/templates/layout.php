<!doctype html>
<html lang="fr-FR">
        <meta charset="utf-8">
        <title>Breaking Journey</title>
        <link style="width: 30px;" rel="icon" href="../assets/logo/icon.ico" type="image/ico">
    </head>
    <body>
        <?= $content; ?>
    </body>
</html>
