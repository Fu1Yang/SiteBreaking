<?php
return [
    'host' => 'smtp.outlook.office365.com',
    'username' => 'yang.fu@live.fr',
    'password' => 'Prince3785@28',
    'port' => 587,
    'encryption' => 'tls'
];
